package com.example.zeeaquarium;

public interface ITrafficLight {
    void setValue(DeviceStatus status);

    DeviceStatus getValue();

    void setGrayoutColoring();

    void setDefaultColoring();
}
