package com.example.zeeaquarium;

public class DeviceSwitchStatus {
    private String name;
    private boolean status;

    public DeviceSwitchStatus(String name, String status) {
        this.name = name;
        this.status = status.equals("True");
    }

    public String getName() {
        return this.name;
    }

    public boolean getStatus() {
        return this.status;
    }

    public String getStatusString() {
        return this.status ? "True" : "False";
    }
}
