package com.example.zeeaquarium;

public class DeviceStatus {
    public String name;
    public SwitchStatus status;
    private long timeStamp;

    public DeviceStatus(String name, String value) {
        this.name = name;
        this.timeStamp = System.currentTimeMillis();

        this.status = value.equals("1")
            ? SwitchStatus.ON
            : value.equals("0")
                ? SwitchStatus.OUT
                : SwitchStatus.UNKNOWN;
    }

    public String getName() {
        return this.name;
    }

    public SwitchStatus getStatus() {
        return this.status;
    }

    public long getTimeStamp() {
        return this.timeStamp;
    }
}
