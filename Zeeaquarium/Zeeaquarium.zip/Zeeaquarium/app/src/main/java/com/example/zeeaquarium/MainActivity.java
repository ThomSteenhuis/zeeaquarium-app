package com.example.zeeaquarium;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Switch;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.github.anastr.speedviewlib.Speedometer;
import com.microsoft.signalr.HubConnection;
import com.microsoft.signalr.HubConnectionBuilder;
import com.microsoft.signalr.HubConnectionState;

import org.json.JSONArray;
import org.json.JSONException;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Timer;

import io.reactivex.Single;

public class MainActivity extends AppCompatActivity {
    private static final String SIGNALR_URL = "https://zeeaquarium-streamingapp.azurewebsites.net/";
    private static final String TOKEN = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJodHRwOi8vc2NoZW1hcy5taWNyb3NvZnQuY29tL3dzLzIwMDgvMDYvaWRlbnRpdHkvY2xhaW1zL3JvbGUiOiJ1c2VyIiwiZXhwIjoxNjUwMjY1ODU5LCJpc3MiOiJodHRwczovL3plZWFxdWFyaXVtLXN0cmVhbWluZ2h1Yi5henVyZXdlYnNpdGVzLm5ldCIsImF1ZCI6Imh0dHBzOi8vemVlYXF1YXJpdW0tc3RyZWFtaW5naHViLmF6dXJld2Vic2l0ZXMubmV0In0.1FgE31ExdF-4H-RcNURIK-B-67dw2I39Oi4aSCVTKdI";

    private RequestQueue requestQueue;
    private Timer timer;
    private HubConnection hubConnection;

    private List<IMeter> meters = new ArrayList<>();
    private List<IDeviceSwitch> deviceSwitches = new ArrayList<>();
    private List<Screenshot> screenshots = new ArrayList<>();
    private List<ITrafficLight> trafficLights = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        requestQueue = Volley.newRequestQueue(this);
        timer = new Timer();

        hubConnection = HubConnectionBuilder
                .create(SIGNALR_URL + "data")
                .withAccessTokenProvider(Single.defer(() -> {
                    return Single.just(TOKEN);
                }))
                .build();
        hubConnection.start();

        int cnt = 0;
        while(!hubConnection.getConnectionState().equals(HubConnectionState.CONNECTED) && cnt < 50) {
            try {
                cnt ++;
                Thread.sleep(100);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        if (!hubConnection.getConnectionState().equals(HubConnectionState.CONNECTED)) {
            // Close app if connection could not be made
           this.finish();
        }

        // Initialize meters
        meters.add(new WaterTemperatureMeter((Speedometer) findViewById(R.id.watertemperature), this));
        meters.add(new AmbientTemperatureMeter((Speedometer) findViewById(R.id.ambienttemperature), this));
        meters.add(new WaterVolumeMeter((Speedometer) findViewById(R.id.watervolume), this));
        meters.add(new WaterVolumeReservoirMeter((Speedometer) findViewById(R.id.watervolume_reservoir), this));
        meters.add(new LightMeter((Speedometer) findViewById(R.id.light), this));
        listenForMeasurements();

        // Initialize traffic lights
        trafficLights.add(new TrafficLight("pomp_rechts_aan", (ImageView) findViewById(R.id.pomp_r_status), this));
        trafficLights.add(new TrafficLight("pomp_links_aan", (ImageView) findViewById(R.id.pomp_l_status), this));
        trafficLights.add(new TrafficLight("verwarming_aan", (ImageView) findViewById(R.id.verwarming_status), this));
        trafficLights.add(new TrafficLight("verlichting_aan", (ImageView) findViewById(R.id.verlichting_status), this));
        trafficLights.add(new TrafficLight("ato_aan", (ImageView) findViewById(R.id.ato_status), this));
        trafficLights.add(new TrafficLight("ventilatoren_aan", (ImageView) findViewById(R.id.ventilatoren_status), this));
        listenForDeviceStatuses();

        // Initialize switches
        deviceSwitches.add(new SimpleDeviceSwitch((Switch) findViewById(R.id.pomp_r), (ProgressBar) findViewById(R.id.pomp_r_syncing), "pomp_rechts", this));
        deviceSwitches.add(new SimpleDeviceSwitch((Switch) findViewById(R.id.pomp_l), (ProgressBar) findViewById(R.id.pomp_l_syncing), "pomp_links", this));
        deviceSwitches.add(new SimpleDeviceSwitch((Switch) findViewById(R.id.verlichting), (ProgressBar) findViewById(R.id.verlichting_syncing), "verlichting", this));
        deviceSwitches.add(new SimpleDeviceSwitch((Switch) findViewById(R.id.verwarming), (ProgressBar) findViewById(R.id.verwarming_syncing), "verwarming", this));
        deviceSwitches.add(new SimpleDeviceSwitch((Switch) findViewById(R.id.ventilatoren), (ProgressBar) findViewById(R.id.ventilatoren_syncing), "ventilatoren", this));
        deviceSwitches.add(new SimpleDeviceSwitch((Switch) findViewById(R.id.ato), (ProgressBar) findViewById(R.id.ato_syncing), "ato", this));
        listenForSwitchStatuses();
        handleSwitchChanges();

        // Initialize screenshot
        screenshots.add(new Screenshot((ImageView) findViewById(R.id.screenshot), this));
        getScreenshots();

        hubConnection.send("joinGroup", "watchers");

        // Check if latest measurements are still up-to-date
        checkUpToDateOnThread();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (hubConnection.getConnectionState().equals(HubConnectionState.CONNECTED)) {
            hubConnection.send("leaveGroup", "viewers");
        }
        hubConnection.stop();
    }

    private void listenForMeasurements() {
        hubConnection.on("broadcastMeasurement", (name, value) -> {
            Measurement measurement = new Measurement(name, value);
            meters.forEach(meter -> meter.setValue(measurement));
        }, String.class, String.class);
    }

    private void listenForDeviceStatuses() {
        hubConnection.on("broadcastMeasurement", (name, value) -> {
            DeviceStatus status = new DeviceStatus(name, value);
            trafficLights.forEach(trafficLight -> trafficLight.setValue(status));
        }, String.class, String.class);
    }

    private void listenForSwitchStatuses() {
        hubConnection.on("deviceStatus", (name, on) -> {
            DeviceSwitchStatus status = new DeviceSwitchStatus(name, on);
            deviceSwitches.forEach(dev -> dev.setStatus(status));
        }, String.class, String.class);
    }

    private void handleSwitchChanges() {
        deviceSwitches.forEach(dev -> {
            dev.status().subscribe(
                    status -> hubConnection.send("switchDevice", status.getName(), status.getStatusString()),
                    error -> error.printStackTrace()
            );
        });
    }

    private void getScreenshots() {
        String url ="https://zeeaquarium-streamingapp.azurewebsites.net/api/screenshot";

        JsonObjectRequest request = new JsonObjectRequest(url, null,
                response -> {
                    screenshots.forEach(s -> {
                        try {
                            JSONArray jsonResponse = (JSONArray) response.get("screenshot");

                            byte[] byteArray = new byte[jsonResponse.length()];
                            for(int idx = 0; idx < jsonResponse.length(); idx++){
                                byteArray[idx] = (byte) jsonResponse.getInt(idx);
                            }

                            s.setScreenshot(byteArray);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    });
                },
                error -> error.printStackTrace()
        ) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> headers = new HashMap<>();
                headers.put("Authorization", "Bearer " + TOKEN);
                return headers;
            }
        };;

        timer.schedule(new AddToQueueTimerTask(requestQueue, request), 0, 1000);
    }

    private void checkUpToDateOnThread() {
        Thread thread = new Thread() {
            @Override
            public void run() {
                try {
                    while (!Thread.interrupted()) {
                        Thread.sleep(500);
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                long currentTimeStamp = System.currentTimeMillis();
                                meters.forEach(meter -> {
                                    if (currentTimeStamp - meter.getValue().getTimeStamp() > 10000l
                                            || meter.getValue().getValue() == 0f) {
                                        meter.setGrayoutColoring();
                                    } else {
                                        meter.setDefaultColoring();
                                    }
                                });
                                trafficLights.forEach(trafficLight -> {
                                    if (currentTimeStamp - trafficLight.getValue().getTimeStamp() > 10000l
                                            || trafficLight.getValue().getStatus().equals(SwitchStatus.UNKNOWN)) {
                                        trafficLight.setGrayoutColoring();
                                    } else {
                                        trafficLight.setDefaultColoring();
                                    }
                                });
                            }
                        });
                    }
                }
                catch (InterruptedException e) {
                }
            }
        };
        thread.start();
    }

    private void createNotificationChannel() {
        // Create the NotificationChannel, but only on API 26+ because
        // the NotificationChannel class is new and not in the support library
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = getString(R.string.channel_name);
            String description = getString(R.string.channel_description);
            int importance = NotificationManager.IMPORTANCE_DEFAULT;
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, name, importance);
            channel.setDescription(description);
            // Register the channel with the system; you can't change the importance
            // or other notification behaviors after this
            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }
    }

}