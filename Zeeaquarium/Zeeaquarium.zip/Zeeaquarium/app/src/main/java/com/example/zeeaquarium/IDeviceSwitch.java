package com.example.zeeaquarium;

import io.reactivex.Observable;

public interface IDeviceSwitch {
    void setStatus(DeviceSwitchStatus status);

    Observable<DeviceSwitchStatus> status();
}
