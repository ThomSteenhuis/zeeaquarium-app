package com.example.zeeaquarium;

public class Measurement {
    private String name;
    private float value;
    private long timeStamp;

    public Measurement(String name, String value) {
        this.name = name;
        this.timeStamp = System.currentTimeMillis();

        try {
            this.value = Float.parseFloat(value);
        } catch(NumberFormatException e) {
            this.value = 0;
        }
    }

    public String getName() {
        return this.name;
    }

    public long getTimeStamp() {
        return this.timeStamp;
    }

    public float getValue() {
        return this.value;
    }
}
